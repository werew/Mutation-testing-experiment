#!/bin/sh

./gradlew clean && \
./gradlew build && \
./gradlew test  && \
./gradlew jacocoTestReport && \ #https://docs.gradle.org/current/userguide/jacoco_plugin.html
./gradlew pitest

