#!/bin/sh

PROJECTS="JavaHamcrest  dagger  javapoet  moshi  retrofit  spring-petclinic  vectalign"

for dir in $PROJECTS
do
	echo "######################################"
	echo "Launching tests for $dir"
	echo "######################################"

	cd $dir
	./run.sh || exit 1
	cd ..
done
