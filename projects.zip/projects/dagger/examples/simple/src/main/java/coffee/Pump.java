package coffee;

interface Pump {
  void pump();
}
