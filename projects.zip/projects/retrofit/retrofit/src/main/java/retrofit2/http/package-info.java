// Copyright 2014 Square, Inc.

/** Annotations for interface methods to control the HTTP request behavior. */
package retrofit2.http;
