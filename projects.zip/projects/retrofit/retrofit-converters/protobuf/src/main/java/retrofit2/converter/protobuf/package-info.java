@ParametersAreNonnullByDefault
package retrofit2.converter.protobuf;

import javax.annotation.ParametersAreNonnullByDefault;
