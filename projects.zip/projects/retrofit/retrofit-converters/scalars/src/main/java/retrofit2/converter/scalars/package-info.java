@ParametersAreNonnullByDefault
package retrofit2.converter.scalars;

import javax.annotation.ParametersAreNonnullByDefault;
