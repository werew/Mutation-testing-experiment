@ParametersAreNonnullByDefault
package retrofit2.converter.wire;

import javax.annotation.ParametersAreNonnullByDefault;
