@ParametersAreNonnullByDefault
package retrofit2.converter.simplexml;

import javax.annotation.ParametersAreNonnullByDefault;
