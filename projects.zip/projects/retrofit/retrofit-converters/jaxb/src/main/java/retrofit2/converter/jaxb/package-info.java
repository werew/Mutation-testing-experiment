@ParametersAreNonnullByDefault
package retrofit2.converter.jaxb;

import javax.annotation.ParametersAreNonnullByDefault;
