@ParametersAreNonnullByDefault
package retrofit2.converter.gson;

import javax.annotation.ParametersAreNonnullByDefault;
