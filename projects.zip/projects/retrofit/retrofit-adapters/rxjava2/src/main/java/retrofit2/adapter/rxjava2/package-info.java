@ParametersAreNonnullByDefault
package retrofit2.adapter.rxjava2;

import javax.annotation.ParametersAreNonnullByDefault;
