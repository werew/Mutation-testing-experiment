@ParametersAreNonnullByDefault
package retrofit2.adapter.guava;

import javax.annotation.ParametersAreNonnullByDefault;
