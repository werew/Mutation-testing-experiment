@ParametersAreNonnullByDefault
package retrofit2.adapter.rxjava;

import javax.annotation.ParametersAreNonnullByDefault;
