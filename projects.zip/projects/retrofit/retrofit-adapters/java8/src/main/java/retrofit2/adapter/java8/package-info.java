@ParametersAreNonnullByDefault
package retrofit2.adapter.java8;

import javax.annotation.ParametersAreNonnullByDefault;
