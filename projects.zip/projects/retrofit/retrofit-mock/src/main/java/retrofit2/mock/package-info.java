@ParametersAreNonnullByDefault
package retrofit2.mock;

import javax.annotation.ParametersAreNonnullByDefault;
