#!/bin/sh
mvn clean test org.pitest:pitest-maven:mutationCoverage
